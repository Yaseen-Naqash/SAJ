from django.apps import AppConfig

class ANotificationManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a_institution_management'
    verbose_name = 'شعب'
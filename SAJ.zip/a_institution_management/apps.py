from django.apps import AppConfig


class AInstitutionManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a_institution_management'

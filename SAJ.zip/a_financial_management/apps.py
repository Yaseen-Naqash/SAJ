from django.apps import AppConfig


class AFinancialManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a_financial_management'
    verbose_name = 'مالی'

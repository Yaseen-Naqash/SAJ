from django.apps import AppConfig


class ACourseManagementConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'a_course_management'
    verbose_name = 'آموزشی'